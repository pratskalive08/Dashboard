package com.mapbox.storelocator.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mapbox.storelocator.R;
import com.mapbox.storelocator.activity.MapActivity;
import com.mapbox.storelocator.model.IndividualLocation;

import java.util.List;

import static android.support.v4.content.ContextCompat.startActivity;
import static com.mapbox.mapboxsdk.Mapbox.getApplicationContext;

/**
 * RecyclerView adapter to display a list of location cards on top of the map
 */
public class LocationRecyclerViewAdapter extends
  RecyclerView.Adapter<LocationRecyclerViewAdapter.ViewHolder> {

  private List<IndividualLocation> listOfLocations;
  private Context context;
  private int selectedTheme;
  private static ClickListener clickListener;
  private Drawable emojiForCircle = null;
  private Drawable backgroundCircle = null;
  private int upperCardSectionColor = 0;

  private int locationNameColor = 0;
  private int locationAddressColor = 0;
  private int locationPhoneNumColor = 0;
  private int locationPhoneHeaderColor = 0;
  private int locationHoursColor = 0;
  private int locationHoursHeaderColor = 0;
  private int locationDistanceNumColor = 0;
  private int milesAbbreviationColor = 0;
  private static String str_val=" ";


  public LocationRecyclerViewAdapter(List<IndividualLocation> styles,
                                     Context context, ClickListener cardClickListener, int selectedTheme) {
    this.context = context;
    this.listOfLocations = styles;
    this.selectedTheme = selectedTheme;
    this.clickListener = cardClickListener;
  }

  @Override
  public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    int singleRvCardToUse = R.layout.single_location_map_view_rv_card;
    View itemView = LayoutInflater.from(parent.getContext()).inflate(singleRvCardToUse, parent, false);
    return new ViewHolder(itemView);
  }

  public interface ClickListener {
    void onItemClick(int position);


  }

  @Override
  public int getItemCount() {
    return listOfLocations.size();
  }

  @Override
  public void onBindViewHolder(ViewHolder card, int position) {

    IndividualLocation locationCard = listOfLocations.get(position);
    str_val=locationCard.getName();
    card.nameTextView.setText(locationCard.getName());
    card.addressTextView.setText(locationCard.getAddress());
    card.phoneNumTextView.setText(locationCard.getPhoneNum());
    card.hoursTextView.setText(locationCard.getHours());
    card.distanceNumberTextView.setText(locationCard.getDistance());


    switch (selectedTheme) {
      case R.style.AppTheme_Blue:
        emojiForCircle = ResourcesCompat.getDrawable(context.getResources(), R.drawable.ice_cream_icon, null);
        backgroundCircle = ResourcesCompat.getDrawable(context.getResources(), R.drawable.blue_circle, null);
        setColors(R.color.colorPrimary_blue, R.color.white, R.color.white, R.color.cardHourAndPhoneTextColor_blue,
          R.color.cardHourAndPhoneHeaderTextColor_blue, R.color.cardHourAndPhoneTextColor_blue,
          R.color.cardHourAndPhoneHeaderTextColor_blue, R.color.white, R.color.white);
        setAlphas(card, .41f, .48f, 100f, .48f,
          100f,
          .41f);


    }

    card.emojiImageView.setImageDrawable(emojiForCircle);
    card.constraintUpperColorSection.setBackgroundColor(upperCardSectionColor);
    card.backgroundCircleImageView.setImageDrawable(backgroundCircle);
    card.nameTextView.setTextColor(locationNameColor);
    card.phoneNumTextView.setTextColor(locationPhoneNumColor);
    card.hoursTextView.setTextColor(locationHoursColor);
    card.hoursHeaderTextView.setTextColor(locationHoursHeaderColor);
    card.distanceNumberTextView.setTextColor(locationDistanceNumColor);
    card.milesAbbreviationTextView.setTextColor(milesAbbreviationColor);
    card.addressTextView.setTextColor(locationAddressColor);
    card.phoneHeaderTextView.setTextColor(locationPhoneHeaderColor);

  }

  private void setColors(int colorForUpperCard, int colorForName, int colorForAddress,
                         int colorForHours, int colorForHoursHeader, int colorForPhoneNum,
                         int colorForPhoneHeader, int colorForDistanceNum, int colorForMilesAbbreviation) {
    upperCardSectionColor = ResourcesCompat.getColor(context.getResources(), colorForUpperCard, null);
    locationNameColor = ResourcesCompat.getColor(context.getResources(), colorForName, null);
    locationAddressColor = ResourcesCompat.getColor(context.getResources(), colorForAddress, null);
    locationHoursColor = ResourcesCompat.getColor(context.getResources(), colorForHours, null);
    locationHoursHeaderColor = ResourcesCompat.getColor(context.getResources(), colorForHoursHeader, null);
    locationPhoneNumColor = ResourcesCompat.getColor(context.getResources(), colorForPhoneNum, null);
    locationPhoneHeaderColor = ResourcesCompat.getColor(context.getResources(), colorForPhoneHeader, null);
    locationDistanceNumColor = ResourcesCompat.getColor(context.getResources(), colorForDistanceNum, null);
    milesAbbreviationColor = ResourcesCompat.getColor(context.getResources(), colorForMilesAbbreviation, null);
  }

  private void setAlphas(ViewHolder card, float addressAlpha, float hoursHeaderAlpha, float hoursNumAlpha,
                         float phoneHeaderAlpha, float phoneNumAlpha, float milesAbbreviationAlpha) {
    card.addressTextView.setAlpha(addressAlpha);
    card.hoursHeaderTextView.setAlpha(hoursHeaderAlpha);
    card.hoursTextView.setAlpha(hoursNumAlpha);
    card.phoneHeaderTextView.setAlpha(phoneHeaderAlpha);
    card.phoneNumTextView.setAlpha(phoneNumAlpha);
    card.milesAbbreviationTextView.setAlpha(milesAbbreviationAlpha);
  }


  static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView nameTextView;
    TextView addressTextView;
    TextView phoneNumTextView;
    TextView hoursTextView;
    TextView distanceNumberTextView;
    TextView hoursHeaderTextView;
    TextView milesAbbreviationTextView;
    TextView phoneHeaderTextView;
    ConstraintLayout constraintUpperColorSection;
    CardView cardView;
    ImageView backgroundCircleImageView;
    ImageView emojiImageView;
    Button visit;

    ViewHolder(View itemView) {
      super(itemView);
      nameTextView = itemView.findViewById(R.id.location_name_tv);
      addressTextView = itemView.findViewById(R.id.location_description_tv);
      phoneNumTextView = itemView.findViewById(R.id.location_phone_num_tv);
      phoneHeaderTextView = itemView.findViewById(R.id.phone_header_tv);
      hoursTextView = itemView.findViewById(R.id.location_hours_tv);
      backgroundCircleImageView = itemView.findViewById(R.id.background_circle);
      emojiImageView = itemView.findViewById(R.id.emoji);
      constraintUpperColorSection = itemView.findViewById(R.id.constraint_upper_color);
      distanceNumberTextView = itemView.findViewById(R.id.distance_num_tv);
      hoursHeaderTextView = itemView.findViewById(R.id.hours_header_tv);
      milesAbbreviationTextView = itemView.findViewById(R.id.miles_mi_tv);
      visit= itemView.findViewById(R.id.visit);
      visit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
          Intent intent = new Intent (view.getContext(), Slot_selecter.class);
          intent.putExtra("store",str_val);
          view.getContext().startActivity(intent);
        }
      });
      cardView = itemView.findViewById(R.id.map_view_location_card);
      cardView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
          clickListener.onItemClick(getLayoutPosition());

          CharSequence text = "Hello toast!";
          int duration = Toast.LENGTH_SHORT;

          Toast toast = Toast.makeText(getApplicationContext(), text, duration);
          toast.show();
        }
      });
    }


    @Override
    public void onClick(View view) {
      Intent intent = new Intent (view.getContext(), Slot_selecter.class);
      view.getContext().startActivity(intent);
    }
  }
}
