package com.mapbox.storelocator.adapter;

public class Last_page {
}
